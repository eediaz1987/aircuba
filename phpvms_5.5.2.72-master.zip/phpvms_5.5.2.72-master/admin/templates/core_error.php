<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<div class="ui-widget" style="margin: 4px 0 4px 0">
	<div style="padding: 0pt 0.7em;" class="ui-state-error ui-corner-all"> 
		<p><span style="float: left; margin-right: 0.3em;" class="ui-icon ui-icon-alert"></span> 
		<?php echo $message;?></p>
	</div>
</div>