<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<?php
echo '<div id="success" class="messagebar" style="float: right; margin-top: 30px;">'.$message.'</div>';
?>