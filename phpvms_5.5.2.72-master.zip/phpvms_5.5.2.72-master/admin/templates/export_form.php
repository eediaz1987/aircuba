<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Export Schedules</h3>
<p>This allows you mass export your schedules, and then reimport them with all your modifications.</p>
<p><a class="button" href="<?php echo adminaction('/import/processexport');?>">Click to export</a></p>