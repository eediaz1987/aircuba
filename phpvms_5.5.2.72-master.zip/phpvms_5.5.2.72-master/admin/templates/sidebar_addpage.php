<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Tasks</h3>
<ul class="filetree treeview-famfamfam">
	<li><span class="file">
		<a href="<?php echo SITE_URL?>/admin/index.php/sitecms/addpageform">Add Page</a>
	</span></li>
	<li><span class="file">
		<a href="<?php echo SITE_URL?>/admin/index.php/sitecms/viewpages">View Pages</a>
	</span></li>

</ul>
<h3>Help</h3>
<p><strong>Page Name</strong> This is the page name, which is what will show in the navigation bar.</p>

<p><strong>Public</strong> If it's public, then a user doesn't have to be logged in to see the page. If it's unchecked, only members can see the page.</p>

<p><strong>Enabled</strong> If the box is checked, then the page is enabled. If it's not, then the page is not available to anyone.</p>

<p><strong>Page Content</strong> This is the content of the page. You can add PHP by using the PHP tags. HTML can also be entered directly.</p>