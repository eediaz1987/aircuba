<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Tasks</h3>
<ul class="filetree treeview-famfamfam">
	<li><span class="file">
		<a id="dialog" class="jqModal" href="<?php echo SITE_URL?>/admin/action.php/settings/addfield">Add a Custom Field</a>
	</span></li>
</ul>
<h3>Help</h3>
<p>You can add custom fields here. These fields can/will show up in the Pilot's profile. You can also restrict this field to only be seen and/or edited by an admin. For instance, you can add a field called "Title", which can be only filled by out an administrator.</p>