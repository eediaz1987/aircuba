<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Tasks</h3>
<ul class="filetree treeview-famfamfam">
	<li><span class="file">
		<a id="dialog" class="jqModal" href="<?php echo SITE_URL?>/admin/action.php/downloads/addcategory">Add a Category</a>
	</span></li>
	<li><span class="file">
		<a id="dialog" class="jqModal" href="<?php echo SITE_URL?>/admin/action.php/downloads/adddownload">Add a Download</a>
	</span></li>

</ul>
<h3>Help</h3>
<p>These are downloads available for your members</p>