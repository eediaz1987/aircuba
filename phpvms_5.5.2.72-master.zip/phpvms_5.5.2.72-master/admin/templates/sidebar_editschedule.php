<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
</ul>
<h3>Help</h3>
<p>When you add a schedule, you can add it on a per-airline basis.</p>
<p>The time can be added in any format, these are just for informational purposes</p>
<p>The distance and flight time can also be added in any format, as they are for information</p>
<p>Distance is in the units that are set in your config file</p>
<p>Notes can be used to add schedule frequency, or any other related information.</p>