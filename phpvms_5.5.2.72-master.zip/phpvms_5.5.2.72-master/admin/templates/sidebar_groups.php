<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Tasks</h3>
<ul class="filetree treeview-famfamfam">
	<li><span class="file">
		<a href="<?php echo SITE_URL?>/admin/index.php/pilotadmin/addgroup">Add Group</a>
	</span></li>
	
</ul>
<h3>Help</h3>
<p>You can set up additional groups to add pilots into, for organizational purposes. The administrators group cannot be deleted. Users added to this group will have access to this administration panel.</p>