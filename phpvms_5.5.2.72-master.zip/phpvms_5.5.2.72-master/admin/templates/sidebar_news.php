<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Tasks</h3>
<ul class="filetree treeview-famfamfam">
	<li><span class="file">
		<a href="<?php echo SITE_URL?>/admin/index.php/sitecms/addnews">Add News</a>
	</span></li>
</ul>

<h3>Help</h3>
<p>You can add news items here; they will show up on the front page of your site.</p>
<p>To delete pages, you must double click on the delete button, as to not accidently delete an item</p>