<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Help</h3>
<p>This is the list of pilots. Click "Options" to view more options for the pilot selected.</p>