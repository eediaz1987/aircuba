<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Tasks</h3>
<ul class="filetree treeview-famfamfam">
	<li><span class="file">
		<a id="dialog" class="jqModal" href="<?php echo SITE_URL?>/admin/action.php/settings/addpirepfield">Add a Custom Field</a>
	</span></li>
</ul>
<h3>Help</h3>
<p>You can add custom PIREP fields here. These will be made available to fill out when a pilot files a PIREP.</p>