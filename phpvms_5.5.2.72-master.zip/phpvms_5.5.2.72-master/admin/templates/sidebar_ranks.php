<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Tasks</h3>
<ul class="filetree treeview-famfamfam">
	<li><span class="file">
		<a id="dialog" class="jqModal" href="<?php echo SITE_URL?>/admin/action.php/pilotranking/addrank">Add Rank</a>
	</span></li>
	<li><span class="file">
		<a href="<?php echo SITE_URL?>/admin/index.php/maintenance/calculateranks">Recalculate Ranks</a>
	</span></li>
</ul>
<h3>Help</h3>
<p>These are the ranks which your pilots can obtain. They are a automatically calculated
	when a PIREP is accepted or rejected by an administrator, or when a change is 
	made to any of the ranks. The pilot profile displays the amount of hours until
	the next rank is obtained.</p>