<?php
$this->log('here', 'hooks');