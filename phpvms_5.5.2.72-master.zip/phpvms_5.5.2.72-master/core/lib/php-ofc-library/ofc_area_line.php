<?php

class area_line extends area_base
{
	public function __construct()
	{
		$this->type      = "area_line";
		parent::area_base();
	}
}
