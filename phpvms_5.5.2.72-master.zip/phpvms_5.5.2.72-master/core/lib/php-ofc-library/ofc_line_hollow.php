<?php

class line_hollow extends line_base
{
	public function __construct()
	{
		$this->type      = "line_hollow";
	}
}