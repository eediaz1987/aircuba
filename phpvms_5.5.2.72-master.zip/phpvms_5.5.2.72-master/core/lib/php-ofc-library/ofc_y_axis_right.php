<?php

class y_axis_right extends y_axis_base
{
	public function __construct(){}
}