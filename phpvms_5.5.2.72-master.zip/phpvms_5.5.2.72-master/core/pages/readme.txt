All of your site's static content pages are here.
They can be edited through the administrators panel. 

But to add in additional tags, such as calling in a
module (using Template::ShowModule(...)), then you can
place those directly in here