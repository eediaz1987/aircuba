<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Thanks!</h3>
<p>Your request has been submitted, we will be in touch shortly.</p>