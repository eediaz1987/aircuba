<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<?php
echo '<div id="success">'.$message.'</div>';
?>