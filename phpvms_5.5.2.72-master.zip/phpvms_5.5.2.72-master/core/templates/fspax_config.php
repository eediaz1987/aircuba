<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
menu_name=<?php echo substr(SITE_NAME, 0, 49);?>;
base_url=<?php echo SITE_URL; ?>; 
path_stats=index.php/acars;  		
path_export=action.php/acars/fspax;	
username=<?php echo $pilotcode?>;		
password=none; 