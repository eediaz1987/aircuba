<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<?php
    /* This page should be a complete HTML page */
?>
<html>
<head>
<title>Down for maintenance - phpVMS Virtual Airline</title>
<style type="text/css">
body { font-family: verdana;  font-size: 16px; color: #001B6B }
h1 { font-weight:16px;font-size:18px;color:#6B001B;margin:0 0 4px 0; }
div#codon_crit_error { border:#999 1px solid;background-color:#fff;padding:20px 20px 12px 20px;}
</style>
</head>
<body>		
    <div id="codon_crit_error" >
        <h1>Down for maintenance</h1>
        <p>We are currently down for maintenance, please check back soon.</p>
    </div>
</body>
</html>