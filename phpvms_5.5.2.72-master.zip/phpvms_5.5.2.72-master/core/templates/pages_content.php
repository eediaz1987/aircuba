<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h1><?php echo $pagename;?></h1>
<div>
<?php echo html_entity_decode($content);?>
</div>