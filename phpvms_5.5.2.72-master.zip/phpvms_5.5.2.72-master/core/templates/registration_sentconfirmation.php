<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Confirmation Sent</h3>

<p>Thanks for registering for <?php echo SITE_NAME; ?>, you will be notified via email of your registration status.</p>