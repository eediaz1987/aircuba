<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Login required!</h3>
<p>You must be logged in to access this area! <a href="<?php echo url('/login'); ?>">Click here to login</a></p>