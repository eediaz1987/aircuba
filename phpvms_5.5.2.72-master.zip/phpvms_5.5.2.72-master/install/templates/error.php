<?php
echo '<div id="error">'.$message.'</div>';
?>